const serverApiUrl="http://192.168.2.212:80/www_weijia/";
const serverImgUrl="http://www.itinhs.com/wx/static/images/";
const serverCssUrl="http://www.itinhs.com/wx/static/css/";
const serverJsUrl="http://www.itinhs.com/wx/static/js/";

export default{ 
	serverApiUrl,serverImgUrl,serverCssUrl,serverJsUrl
}