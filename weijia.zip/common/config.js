const serverUrl="http://127.0.0.1:80/www_weijia/";
const serverImgUrl="http://127.0.0.1:80/www_weijia/public/weixin-img/";

export default{ 
	serverUrl,serverImgUrl
}