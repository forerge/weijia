<template>
    <view class='page'>
		<!-- 位置搜索板块 start -->
		<view class="topsearch">
			<view class="location" @click="showCitySelect">
				<text class="address" v-text="cityName"></text>
				<image class="img" :src="serverImgUrl+downUpImg"></image>
			</view>  
			<view class="searchInput">
				<view class="hr"></view>
				<image class="img" :src="serverImgUrl+'sousuo.png'" ></image>
				<input class="input" type="text" placeholder="请输入小区名或地址" @focus="hideCitySelect"/>
			</view>
		</view>
		<!-- 位置搜索板块 end -->
		
		<!-- 轮播图板块 start -->
		<swiper  :indicator-dots="true" :autoplay="true" :interval="3000"  :circular="true" class="lunbo" >
			<swiper-item>
				<image class="lunboimg" :src="serverImgUrl+'banner1.png'" mode="widthFix"></image>
			</swiper-item>
			<swiper-item>
				<image class="lunboimg" :src="serverImgUrl+'banner2.png'" mode="widthFix"></image>
			</swiper-item> 
		</swiper>
      <!-- 轮播图板块 end -->
		
	<!-- 导航栏板块 start-->
	<view class="grid grid-col-4 nav-list">
		<view class="grid-list">
				<navigator url="../weijiahaofang/weijiahaofang" hover-class="none">
			<image :src="serverImgUrl+'nav01.png'" ></image>
			<text>唯家好房</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../zhengzhufabu/zhengzhufabu" hover-class="none">
			<image :src="serverImgUrl+'nav02.png'" ></image>
			<text>整租</text>
			</navigator>
		</view>
		<view class="grid-list">
			<navigator url="../zhengzhufabu/zhengzhufabu" hover-class="none">
			<image :src="serverImgUrl+'nav03.png'" ></image>
			<text>合租</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../fangyuanshangchuan/fangyuanshangchuan" open-type="switchTab" hover-class="none">
			<image :src="serverImgUrl+'nav04.png'" ></image>
			<text>上传房源</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="javascript:void(0)" hover-class="none">
			<image :src="serverImgUrl+'nav05.png'" ></image>
			<text>职业房东</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../jingjirenjiaru/jingjirenjiaru" hover-class="none">
			<image :src="serverImgUrl+'nav06.png'" ></image>
			<text>职业经纪人</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../fangdongweituo/fangdongweituo1" hover-class="none">
			<image :src="serverImgUrl+'nav07.png'" ></image>
			<text>房东委托</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../yuyuekanfang/yuyuekanfang" hover-class="none">
			<image :src="serverImgUrl+'nav08.png'" ></image>
			<text>预约看房</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../wuyejiaojie/wuyejiaojie" hover-class="none">
			<image :src="serverImgUrl+'nav09.png'" ></image>
			<text>物业交接</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../zhaoshiyou/zhaoshiyou" hover-class="none">
			<image :src="serverImgUrl+'nav010.png'" ></image>
			<text>找室友</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../wodehetong/wodehetong2" hover-class="none">
			<image :src="serverImgUrl+'nav011.png'" ></image>
			<text>我的合同</text>
			 </navigator>
		</view>
		<view class="grid-list">
			<navigator url="../wodeqianbao/wodeqianbao" hover-class="none">
			<image :src="serverImgUrl+'nav012.png'" ></image>
			<text>我的钱包</text>
			 </navigator>
		</view>
	</view>
	<!-- 导航栏板块 end-->
	
		<!-- 推荐模块开始 -->
		<view class="tuijian">
			<view class="title">
				推荐
			</view>
			<tuijianContentList :tuijianContent="tuijianContent"/>
		</view>
		<!-- 推荐模块结束 -->
		<!-- 城市选择组件 -->
		<citySelect class="uni-select" :class="{active:isActive }" :listData="listData" :quickPanelData="quickPanelData" @chooseItem="chooseItem" />
    </view>
</template>
<!-- 二、逻辑层 -->
<script>
	import city from '@/common/city.js'
	import citySelect from '@/components/uni-city-select/uni-city-select.vue'
	import tuijianContentList from '@/components/dzy-tuijian-content-list/dzy-tuijian-content-list.vue'
	export default {
		components:{
			citySelect,
			tuijianContentList
		},
		//1.初始化模板变量
		data() {
			return {
				//获取自定义$commonConfig对象中的服务器地址
				serverUrl:this.$commonConfig.serverUrl,
				serverImgUrl:this.$commonConfig.serverImgUrl,
				//推荐内容
				tuijianContent:[],
				//获取定位城市处->上下图标切换
				downUpImg:"xiala-down.png",
				
				//获取定位城市
				cityName:'上海',//默认定位城市
				
				//城市选择面板
				isActive:false,
				listData: city,
				quickPanelData:[
					{
					title:'当前城市',
					navName: '当前',
					data:['上海'], //默认显示当前城市
					height: 150
				},
				{
					title:'热门城市',
					navName: '热',
					data:['上海','北京','成都','昆明','西安'],
					height: 224
				}
				]
			}
		},
		
		//2.页面加载完成、页面卸载事件
		onLoad() {
			//执行uni-app提供的类似ajax异步加载
			uni.request({ 
				url: this.serverUrl+'home/house/kuai_hot', //请求url
				method: 'POST',               //请求方式
				data: {},                     //传递的数据
				success: res => {   //成功执行回调函数
					if(res.statusCode==200){
						// console.log(JSON.parse(res.data[0].h_uploads)[0]);//获取服务器数据，并赋值
						// console.log(res.data[0].h_config);//获取服务器数据，并赋值
						this.tuijianContent= res.data;
						// this.tuijianContent=[
						// 	{
						// 	imgUrl:this.serverUrl+'public/uploads/'+JSON.parse(res.data[0].h_uploads)[0],
						// 	title:res.data[0].h_state+'.'+res.data[0].h_qv+' '+res.data[0].h_shi+'居室.'+res.data[0].h_ting+'厅.'+res.data[0].h_wei+'卫',
						// 	area:res.data[0].h_space+'㎡',
						// 	floor:res.data[0].h_addr+'/'+res.data[0].h_floor+'层',
						// 	towards:'朝'+res.data[0].h_xiang,
						// 	subwayDistance:'距'+res.data[0].h_metro_no+'线地铁'+res.data[0].h_metro_length+'m',
						// 	pledge:res.data[0].h_rule,
						// 	subway:res.data[0].h_metro_length<2000?'离地铁近':'',
						// 	veranda:JSON.parse(res.data[0].h_config).yangtai==1?'有阳台':'',
						// 	monthPrice:res.data[0].h_money
						// 	},{
						// 	imgUrl:this.serverUrl+'public/uploads/'+JSON.parse(res.data[1].h_uploads)[0],
						// 	title:res.data[1].h_state+'.'+res.data[1].h_qv+' '+res.data[1].h_shi+'居室.'+res.data[1].h_ting+'厅.'+res.data[1].h_wei+'卫',
						// 	area:res.data[1].h_space+'㎡',
						// 	floor:res.data[1].h_addr+'/'+res.data[1].h_floor+'层',
						// 	towards:'朝'+res.data[1].h_xiang,
						// 	subwayDistance:'距'+res.data[1].h_metro_no+'线地铁'+res.data[1].h_metro_length+'m',
						// 	pledge:res.data[1].h_rule,
						// 	subway:res.data[1].h_metro_length<2000?'离地铁近':'',
						// 	veranda:JSON.parse(res.data[1].h_config).yangtai==1?'有阳台':'',
						// 	monthPrice:res.data[1].h_money
						// 	},{
						// 	imgUrl:this.serverUrl+'public/uploads/'+JSON.parse(res.data[2].h_uploads)[0],
						// 	title:res.data[2].h_state+'.'+res.data[2].h_qv+' '+res.data[2].h_shi+'居室.'+res.data[2].h_ting+'厅.'+res.data[2].h_wei+'卫',
						// 	area:res.data[2].h_space+'㎡',
						// 	floor:res.data[2].h_addr+'/'+res.data[2].h_floor+'层',
						// 	towards:'朝'+res.data[2].h_xiang,
						// 	subwayDistance:'距'+res.data[2].h_metro_no+'线地铁'+res.data[2].h_metro_length+'m',
						// 	pledge:res.data[2].h_rule,
						// 	subway:res.data[2].h_metro_length<2000?'离地铁近':'',
						// 	veranda:JSON.parse(res.data[2].h_config).yangtai==1?'有阳台':'',
						// 	monthPrice:res.data[2].h_money
						// 	}
						// ]
					}else{
						console.log(res);
					}
					
				},
				fail: () => {},
				complete: () => {}
			});
		}, 
		
		//3.事件以及自定义方法存放处
		methods: {
			showCitySelect(){
				this.downUpImg="xiala-up.png";//切换上下图标
				this.isActive=true;
			},
			hideCitySelect(){
				this.downUpImg="xiala-down.png"; //切换上下图标
				this.isActive=false;
			},
			chooseItem(item) {
				this.downUpImg="xiala-down.png"; //切换上下图标
				this.isActive=false; //隐藏城市面板
				this.cityName=item; //赋值给当前定位城市
				this.quickPanelData[0].data=[item]; //赋值给面板当前城市
			}
		}, 
	
	}
</script>
<!-- 三、样式层 -->
<style lang="scss">
@import "../../common/index";
</style>
