const serverUrl="http://www.itinhs.com/wx/";

export default{ 
	serverUrl
}